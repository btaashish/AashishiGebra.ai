import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Play, Book, Clock, BarChart, MessageSquare, Brain } from 'lucide-react';
import { AssessmentGenerator } from '../components/AssessmentGenerator';

export function Course() {
  const { id } = useParams();
  const [showAssessment, setShowAssessment] = useState(false);
  const [showAITutor, setShowAITutor] = useState(false);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Machine Learning Fundamentals</h1>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <span className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                8 weeks
              </span>
              <span className="flex items-center">
                <Book className="h-4 w-4 mr-1" />
                12 modules
              </span>
              <span className="flex items-center">
                <BarChart className="h-4 w-4 mr-1" />
                Beginner
              </span>
            </div>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={() => setShowAITutor(!showAITutor)}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Brain className="h-4 w-4 mr-2" />
              AI Tutor
            </button>
            <button
              onClick={() => setShowAssessment(!showAssessment)}
              className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Take Assessment
            </button>
          </div>
        </div>
      </div>

      {showAITutor && (
        <div className="mb-8 bg-gradient-to-r from-purple-700 to-indigo-800 rounded-lg p-6 text-white">
          <div className="flex items-center mb-4">
            <Brain className="h-6 w-6 mr-2" />
            <h2 className="text-xl font-semibold">KLH.AI Tutor</h2>
          </div>
          <div className="space-y-4">
            <div className="bg-white/10 rounded-lg p-4">
              <p className="text-sm mb-3">
                I notice you're spending more time on supervised learning concepts. 
                Would you like me to explain backpropagation in more detail?
              </p>
              <div className="flex space-x-2">
                <button className="text-sm bg-white/20 hover:bg-white/30 px-4 py-1 rounded-full">
                  Yes, explain more
                </button>
                <button className="text-sm bg-white/10 hover:bg-white/20 px-4 py-1 rounded-full">
                  I'm good for now
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showAssessment && (
        <div className="mb-8">
          <AssessmentGenerator />
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Course Overview</h2>
        <p className="text-gray-600">
          Master the fundamentals of machine learning through hands-on projects and real-world applications.
          This course covers essential concepts, algorithms, and practical implementation using Python.
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4">Course Modules</h2>
        <div className="space-y-4">
          {[
            'Introduction to Machine Learning',
            'Data Preprocessing',
            'Supervised Learning',
            'Unsupervised Learning',
            'Neural Networks Basics'
          ].map((module, index) => (
            <div key={index} className="flex items-center p-4 border rounded-lg hover:bg-gray-50">
              <Play className="h-5 w-5 text-indigo-600 mr-3" />
              <div>
                <h3 className="font-medium text-gray-900">{module}</h3>
                <p className="text-sm text-gray-500">45 minutes</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}