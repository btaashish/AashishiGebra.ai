import React from 'react';
import { CourseCard } from '../components/CourseCard';
import { AIRecommendations } from '../components/AIRecommendations';
import { Rocket, BookOpen, Users, Trophy, Brain } from 'lucide-react';
import type { Course } from '../types';

const featuredCourses: Course[] = [
  {
    id: '1',
    title: 'Machine Learning Fundamentals',
    description: 'Learn the basics of ML with hands-on projects',
    thumbnail: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80',
    instructor: 'Dr. Sarah Chen',
    duration: '8 weeks',
    level: 'Beginner',
    rating: 4.8,
    enrolled: 1234
  },
  {
    id: '2',
    title: 'Advanced Web Development',
    description: 'Master modern web technologies and frameworks',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80',
    instructor: 'John Smith',
    duration: '10 weeks',
    level: 'Advanced',
    rating: 4.9,
    enrolled: 2156
  },
  {
    id: '3',
    title: 'Data Science Essentials',
    description: 'Comprehensive introduction to data science',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80',
    instructor: 'Alex Johnson',
    duration: '12 weeks',
    level: 'Intermediate',
    rating: 4.7,
    enrolled: 1789
  }
];

export function Home() {
  return (
    <div className="space-y-8">
      <section className="text-center mb-12">
        <div className="flex items-center justify-center mb-4">
          <Brain className="h-12 w-12 text-purple-600 mr-3" />
          <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
            KLH.AI
          </h1>
        </div>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Experience the future of learning with our AI-powered platform.
          Personalized paths, intelligent tutoring, and adaptive assessments
          to help you master new skills effectively.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
        {[
          { icon: Brain, title: 'AI Tutoring', desc: 'Personal AI learning assistant' },
          { icon: Rocket, title: 'Smart Path', desc: 'Adaptive learning journey' },
          { icon: BookOpen, title: 'Dynamic Content', desc: 'AI-generated materials' },
          { icon: Trophy, title: 'Real Progress', desc: 'Skill-based achievements' }
        ].map((item, i) => (
          <div key={i} className="bg-white p-6 rounded-lg shadow-sm text-center hover:shadow-md transition-shadow">
            <item.icon className="h-8 w-8 mx-auto text-purple-600 mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
            <p className="text-sm text-gray-500">{item.desc}</p>
          </div>
        ))}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Courses</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
        <div>
          <AIRecommendations />
        </div>
      </div>
    </div>
  );
}