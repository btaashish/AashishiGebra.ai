import React from 'react';
import { CourseCard } from '../components/CourseCard';
import { Settings, Book, Award } from 'lucide-react';
import type { Course } from '../types';

const enrolledCourses: Course[] = [
  {
    id: '1',
    title: 'Machine Learning Fundamentals',
    description: 'Learn the basics of ML with hands-on projects',
    thumbnail: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80',
    instructor: 'Dr. Sarah Chen',
    duration: '8 weeks',
    level: 'Beginner',
    rating: 4.8,
    enrolled: 1234,
    progress: 65
  },
  {
    id: '2',
    title: 'Advanced Web Development',
    description: 'Master modern web technologies and frameworks',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80',
    instructor: 'John Smith',
    duration: '10 weeks',
    level: 'Advanced',
    rating: 4.9,
    enrolled: 2156,
    progress: 30
  }
];

export function Profile() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
              alt="Profile"
              className="h-16 w-16 rounded-full object-cover"
            />
            <div className="ml-4">
              <h1 className="text-2xl font-bold text-gray-900">Alex Johnson</h1>
              <p className="text-gray-500">Web Developer</p>
            </div>
          </div>
          <button className="flex items-center text-gray-600 hover:text-gray-900">
            <Settings className="h-5 w-5 mr-2" />
            Settings
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Book className="h-5 w-5 text-indigo-600 mr-2" />
              <h3 className="font-semibold">Enrolled Courses</h3>
            </div>
            <p className="text-2xl font-bold text-gray-900">4</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Award className="h-5 w-5 text-indigo-600 mr-2" />
              <h3 className="font-semibold">Certificates</h3>
            </div>
            <p className="text-2xl font-bold text-gray-900">2</p>
          </div>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-900 mb-4">My Courses</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {enrolledCourses.map(course => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </div>
    </div>
  );
}