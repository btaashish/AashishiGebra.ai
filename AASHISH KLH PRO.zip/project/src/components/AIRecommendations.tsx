import React, { useState } from 'react';
import { Sparkles, Brain, Target, Rocket, MessageSquare } from 'lucide-react';

export function AIRecommendations() {
  const [activeMode, setActiveMode] = useState<'tutor' | 'career' | 'insights'>('insights');

  const modes = {
    tutor: {
      title: 'AI Tutor Mode',
      content: [
        {
          title: 'Current Focus',
          description: 'Deep dive into React Hooks - Custom Hook Patterns',
          action: 'Start Tutorial Session'
        },
        {
          title: 'Learning Style',
          description: 'Visual learner - Incorporating more diagrams and code visualizations',
          action: 'Adjust Learning Style'
        }
      ]
    },
    career: {
      title: 'Career Insights',
      content: [
        {
          title: 'Recommended Path',
          description: 'Frontend Architect - Strong foundation in React ecosystem',
          action: 'View Roadmap'
        },
        {
          title: 'Project Ideas',
          description: 'Build a real-time collaboration tool using WebSocket',
          action: 'Start Project'
        }
      ]
    },
    insights: {
      title: 'Learning Insights',
      content: [
        {
          title: 'Progress Analysis',
          description: 'Exceptional progress in React, consider exploring Next.js',
          action: 'View Details'
        },
        {
          title: 'Knowledge Graph',
          description: 'Strong in Frontend, recommend Backend integration topics',
          action: 'Explore Topics'
        }
      ]
    }
  };

  const currentMode = modes[activeMode];

  return (
    <div className="bg-gradient-to-r from-purple-700 to-indigo-800 rounded-lg p-6 text-white">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Brain className="h-8 w-8 mr-3" />
          <h2 className="text-2xl font-bold">KLH.AI</h2>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveMode('tutor')}
            className={`px-3 py-1 rounded-full text-sm ${
              activeMode === 'tutor'
                ? 'bg-white text-purple-700'
                : 'bg-white/10 hover:bg-white/20'
            }`}
          >
            Tutor
          </button>
          <button
            onClick={() => setActiveMode('career')}
            className={`px-3 py-1 rounded-full text-sm ${
              activeMode === 'career'
                ? 'bg-white text-purple-700'
                : 'bg-white/10 hover:bg-white/20'
            }`}
          >
            Career
          </button>
          <button
            onClick={() => setActiveMode('insights')}
            className={`px-3 py-1 rounded-full text-sm ${
              activeMode === 'insights'
                ? 'bg-white text-purple-700'
                : 'bg-white/10 hover:bg-white/20'
            }`}
          >
            Insights
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {currentMode.content.map((item, index) => (
          <div key={index} className="bg-white/10 rounded-lg p-4 hover:bg-white/15 transition-colors">
            <h3 className="font-medium mb-2 flex items-center">
              {activeMode === 'tutor' && <MessageSquare className="h-4 w-4 mr-2" />}
              {activeMode === 'career' && <Target className="h-4 w-4 mr-2" />}
              {activeMode === 'insights' && <Sparkles className="h-4 w-4 mr-2" />}
              {item.title}
            </h3>
            <p className="text-sm opacity-90 mb-3">{item.description}</p>
            <button className="text-sm bg-white/20 hover:bg-white/30 px-4 py-1 rounded-full transition-colors">
              {item.action}
            </button>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Rocket className="h-4 w-4 mr-2" />
            <span className="text-sm">AI-Powered Learning Assistant</span>
          </div>
          <button className="text-sm bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors">
            Start Chat
          </button>
        </div>
      </div>
    </div>
  );
}