import React, { useState } from 'react';
import { Brain, CheckCircle, XCircle, RefreshCw } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

export function AssessmentGenerator() {
  const [questions] = useState<Question[]>([
    {
      id: 1,
      question: "What is the primary purpose of React's useEffect hook?",
      options: [
        "To handle side effects in functional components",
        "To create new components",
        "To style components",
        "To handle routing"
      ],
      correctAnswer: 0
    },
    {
      id: 2,
      question: "Which hook is used for managing local state in React?",
      options: [
        "useLocal",
        "useState",
        "useState()",
        "useLocalState"
      ],
      correctAnswer: 1
    }
  ]);

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (optionIndex: number) => {
    setSelectedAnswer(optionIndex);
    setShowResult(true);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(curr => curr + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Brain className="h-6 w-6 text-purple-600 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900">AI Assessment</h2>
        </div>
        <span className="text-sm text-gray-500">
          Question {currentQuestion + 1} of {questions.length}
        </span>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          {questions[currentQuestion].question}
        </h3>
        <div className="space-y-3">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
              className={`w-full text-left p-3 rounded-lg border transition-colors ${
                showResult
                  ? index === questions[currentQuestion].correctAnswer
                    ? 'bg-green-50 border-green-200'
                    : selectedAnswer === index
                    ? 'bg-red-50 border-red-200'
                    : 'bg-gray-50 border-gray-200'
                  : 'hover:bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {showResult && index === questions[currentQuestion].correctAnswer && (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                )}
                {showResult && selectedAnswer === index && index !== questions[currentQuestion].correctAnswer && (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {showResult && (
        <div className="flex justify-between items-center">
          <div className="text-sm">
            {selectedAnswer === questions[currentQuestion].correctAnswer ? (
              <span className="text-green-600">Correct! Well done!</span>
            ) : (
              <span className="text-red-600">Not quite right. Try again!</span>
            )}
          </div>
          {currentQuestion < questions.length - 1 && (
            <button
              onClick={nextQuestion}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <span>Next Question</span>
              <RefreshCw className="h-4 w-4 ml-2" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}