/*
  # Initial Schema Setup for KLH.AI LMS

  1. New Tables
    - users (extends Supabase auth.users)
      - profile information
      - learning preferences
      - achievements
    - courses
      - course details
      - curriculum
      - requirements
    - enrollments
      - user progress
      - completion status
    - assessments
      - quiz data
      - user responses
    - learning_paths
      - career tracks
      - skill paths
    - ai_interactions
      - chat history
      - learning insights

  2. Security
    - RLS policies for all tables
    - User-specific access controls
    - Instructor permissions
*/

-- Users Extension Table
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  avatar_url text,
  bio text,
  learning_style jsonb,
  preferences jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own profile"
  ON public.user_profiles
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.user_profiles
  FOR UPDATE
  USING (auth.uid() = id);

-- Courses Table
CREATE TABLE IF NOT EXISTS public.courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  thumbnail_url text,
  instructor_id uuid REFERENCES auth.users(id),
  level text CHECK (level IN ('Beginner', 'Intermediate', 'Advanced')),
  duration interval,
  curriculum jsonb,
  requirements text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view published courses"
  ON public.courses
  FOR SELECT
  USING (true);

-- Enrollments Table
CREATE TABLE IF NOT EXISTS public.enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  course_id uuid REFERENCES public.courses(id),
  progress jsonb DEFAULT '{"completed": 0, "total": 0}'::jsonb,
  status text DEFAULT 'active' CHECK (status IN ('active', 'completed', 'paused')),
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  UNIQUE(user_id, course_id)
);

ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own enrollments"
  ON public.enrollments
  FOR SELECT
  USING (auth.uid() = user_id);

-- Assessments Table
CREATE TABLE IF NOT EXISTS public.assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES public.courses(id),
  title text NOT NULL,
  questions jsonb NOT NULL,
  passing_score integer DEFAULT 70,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enrolled users can access assessments"
  ON public.assessments
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.enrollments
      WHERE user_id = auth.uid()
      AND course_id = assessments.course_id
    )
  );

-- Learning Paths Table
CREATE TABLE IF NOT EXISTS public.learning_paths (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  courses uuid[] REFERENCES public.courses(id),
  career_track text,
  skills text[],
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.learning_paths ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view learning paths"
  ON public.learning_paths
  FOR SELECT
  USING (true);

-- AI Interactions Table
CREATE TABLE IF NOT EXISTS public.ai_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  session_id uuid DEFAULT gen_random_uuid(),
  interaction_type text CHECK (interaction_type IN ('chat', 'assessment', 'recommendation')),
  content jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.ai_interactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can access their own AI interactions"
  ON public.ai_interactions
  FOR SELECT
  USING (auth.uid() = user_id);

-- Functions
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers
CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_courses_updated_at
  BEFORE UPDATE ON public.courses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();